﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Runtime.InteropServices.ComTypes;

namespace _16._04._24
{
    /// <summary>
    /// Логика взаимодействия для LichnayaZayavka.xaml
    /// </summary>
    public partial class LichnayaZayavka : Window
    {
        private const string connectionString = @"Data Source=DESKTOP-UGJSU56\SQLEXPRESS01;Initial Catalog=Pracktika;Integrated Security=True;";

        public LichnayaZayavka()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }
        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Заполняем ComboBox при загрузке окна
            using (var context = new PracktikaEntities1())
            {
                Podrazdel.ItemsSource = context.Подразделения.ToList();
                Podrazdel.DisplayMemberPath = "Название";
                Podrazdel.SelectedValuePath = "ID_подразделения";

                sotrudnik.ItemsSource = context.Сотрудники.ToList();
                sotrudnik.DisplayMemberPath = "Фамилия";
                sotrudnik.SelectedValuePath = "ID_Сотруника";


            }
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            // Очистка формы
            Фамилия.Text = "";
            Имя.Text = "";
            Отчество.Text = "";
            Телефон.Text = "";
            Email.Text = "";
            Организация.Text = "";
            Примечание.Text = "";
            Дата_рождения.SelectedDate = null;
            Серия.Text = "";
            Номер.Text = "";
            data_nachala.SelectedDate = null;
            date_oconch.SelectedDate = null;


        }

        private void foto_Click(object sender, RoutedEventArgs e)
        {

        }

        private void fail_Click(object sender, RoutedEventArgs e)
        {

        }

        private void press_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из элементов управления
            string startDate = data_nachala.SelectedDate.HasValue ? data_nachala.SelectedDate.Value.ToString("yyyy-MM-dd") : null;
            string endDate = date_oconch.SelectedDate.HasValue ? date_oconch.SelectedDate.Value.ToString("yyyy-MM-dd") : null;
            string department = Podrazdel.SelectedItem.ToString();
            string employee = sotrudnik.SelectedItem.ToString();
            string lastName = Фамилия.Text;
            string firstName = Имя.Text;
            string middleName = Отчество.Text;
            string phone = Телефон.Text;
            string email = Email.Text;
            string organization = Организация.Text;
            string note = Примечание.Text;
            string birthDate = Дата_рождения.SelectedDate.HasValue ? Дата_рождения.SelectedDate.Value.ToString("yyyy-MM-dd") : null;
            string passportSeries = Серия.Text;
            string passportNumber = Номер.Text;

            // Сохраняем данные в таблицу Заявки
            int applicationId = SaveApplication(startDate, endDate, department, employee);

            // Сохраняем данные в таблицу Информация_о_посетителях
            SaveVisitorInfo(applicationId, lastName, firstName, middleName, phone, email, organization, note, birthDate, passportSeries, passportNumber);
        }
        private int SaveApplication(string startDate, string endDate, string department, string employee)
        {
            int applicationId = +1;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Заявки (ID_заявки,Дата_начала, Дата_окончания, ID_подразделения, Сотрудник)
                                OUTPUT INSERTED.ID_заявки
                                VALUES (@StartDate, @EndDate, @Department, @Employee)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate);
                //command.Parameters.AddWithValue("@Department", department);
               // command.Parameters.AddWithValue("@Employee", employee);

                try
                {
                    connection.Open();
                    applicationId = (int)command.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Произошла ошибка при сохранении данных в таблицу Заявки: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            return applicationId;
        }

        private void SaveVisitorInfo(int applicationId, string lastName, string firstName, string middleName, string phone, string email, string organization, string note, string birthDate, string passportSeries, string passportNumber)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Информация_о_посетителях (ID_заявки, Фамилия, Имя, Отчество, Телефон, Email, Организация, Примечание, Дата_рождения, Серия_паспорта, Номер_паспорта)
                                VALUES (@ApplicationId, @LastName, @FirstName, @MiddleName, @Phone, @Email, @Organization, @Note, @BirthDate, @PassportSeries, @PassportNumber)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ApplicationId", applicationId);
                command.Parameters.AddWithValue("@LastName", lastName);
                command.Parameters.AddWithValue("@FirstName", firstName);
                command.Parameters.AddWithValue("@MiddleName", middleName);
                command.Parameters.AddWithValue("@Phone", phone);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Organization", organization);
                command.Parameters.AddWithValue("@Note", note);
                command.Parameters.AddWithValue("@BirthDate", birthDate);
                command.Parameters.AddWithValue("@PassportSeries", passportSeries);
                command.Parameters.AddWithValue("@PassportNumber", passportNumber);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        System.Windows.MessageBox.Show("Данные успешно сохранены в таблицу Информация_о_посетителях!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        System.Windows.MessageBox.Show("Произошла ошибка при сохранении данных в таблицу Информация_о_посетителях.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Произошла ошибка при выполнении запроса: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void Podrazdel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string query = "SELECT Название FROM Подразделения"; // Ваш SQL-запрос для извлечения данных о подразделениях
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string departmentName = reader.GetString(0); // Предполагается, что название подразделения находится в первом столбце
                        Podrazdel.Items.Add(departmentName); // Добавляем название подразделения в комбо-бокс
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    System.Windows.MessageBox.Show("Произошла ошибка при загрузке подразделений: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void sotrudnik_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            {
                string query = "SELECT Фамилия FROM Сотрудники"; // SQL-запрос для извлечения ФИО сотрудников
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);
                    try
                    {
                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            string employeeName = reader.GetString(0); // Предполагается, что ФИО сотрудника находится в первом столбце
                            sotrudnik.Items.Add(employeeName); // Добавляем ФИО сотрудника в комбо-бокс
                            Console.WriteLine("Добавлен сотрудник: " + employeeName); // Отладочное сообщение
                        }
                        reader.Close();
                    }
                    catch (Exception ex)
                    {
                        System.Windows.MessageBox.Show("Произошла ошибка при загрузке сотрудников: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
   