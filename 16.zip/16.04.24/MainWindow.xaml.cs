﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _16._04._24
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string connectionString = @"Data Source=DESKTOP-UGJSU56\SQLEXPRESS01;Initial Catalog=Pracktika;Integrated Security=True;";
        public MainWindow()
        {
            InitializeComponent();

        }

        private string GetMD5Hash(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            Registration registrationForm = new Registration();
            registrationForm.Show();
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {
            string email = Login.Text;
            string password = Password.Text;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                System.Windows.Forms.MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string hashedPassword = GetMD5Hash(password);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT COUNT(*) FROM Пользователи WHERE Email = @Email AND Хэш_пароля = @HashedPassword";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@HashedPassword", hashedPassword);

                try
                {
                    connection.Open();
                    int userCount = (int)command.ExecuteScalar();
                    if (userCount > 0)
                    {
                        System.Windows.Forms.MessageBox.Show("Аутентификация успешна!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Открываем следующую форму
                        TipZayavki nextForm = new TipZayavki();
                        nextForm.Show();
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Неправильный логин или пароль.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("Произошла ошибка при выполнении запроса: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
