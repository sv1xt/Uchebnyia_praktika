﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _16LA
{
    /// <summary>
    /// Логика взаимодействия для LichnayaZayavka.xaml
    /// </summary>
    public partial class LichnayaZayavka : Window
    {
        public LichnayaZayavka()
        {
            InitializeComponent();
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            // Очистка формы
            Фамилия.Text = "";
            Имя.Text = "";
            Отчество.Text = "";
            Телефон.Text = "";
            Email.Text = "";
            Организация.Text = "";
            Примечание.Text = "";
            Дата_рождения.SelectedDate = null;
            Серия.Text = "";
            Номер.Text = "";
            data_nachala.SelectedDate = null;
            date_oconch.SelectedDate = null;

           // loadedPhotoData = null;
            loadedImage.Source = null;
        }

        private void press_Click(object sender, RoutedEventArgs e)
        {

        }

        private void fail_Click(object sender, RoutedEventArgs e)
        {

        }

        private void foto_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
