﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace _16LA
{
    /// <summary>
    /// Логика взаимодействия для Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        private const string connectionString = @"Data Source=KAB17-04\SQLEXPRESS;Initial Catalog=Pracktika;Integrated Security=True;";
        public Registration()
        {
            InitializeComponent();
        }

        private string GetMD5Hash(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void Reg_button_Click(object sender, RoutedEventArgs e)
        {
            string login = Login.Text;
            string password = Password.Text;
            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                System.Windows.Forms.MessageBox.Show("Пожалуйста, заполните все поля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Хэшируем пароль
            string hashedPassword = GetMD5Hash(password);

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Пользователи (Email, Пароль, Хэш_пароля) VALUES (@Email, @Password, @HashedPassword)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", login);
                command.Parameters.AddWithValue("@Password", password);
                command.Parameters.AddWithValue("@HashedPassword", hashedPassword);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        System.Windows.Forms.MessageBox.Show("Регистрация успешно завершена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show("Произошла ошибка при регистрации пользователя.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    System.Windows.Forms.MessageBox.Show("Произошла ошибка при выполнении запроса: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
